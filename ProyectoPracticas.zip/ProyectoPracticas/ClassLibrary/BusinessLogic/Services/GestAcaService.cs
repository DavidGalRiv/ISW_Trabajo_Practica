﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

using GestAca.Entities;
using GestAca.Persistence;
using GestAca.Services;


namespace GestAca.Services
{
    public class GestAcaService : IGestAcaService
    {
        private readonly IDAL dal;

        public GestAcaService(IDAL dal)
        {
            this.dal = dal;
        }

        /// <summary>
        /// Borra todos los datos de la BD
        /// </summary>
        public void RemoveAllData()
        {
            dal.RemoveAllData();
        }

        /// <summary>
        /// Salva todos los cambios que haya habido en el contexto de la aplicación desde la última vez que se hizo Commit
        /// </summary>
        public void Commit()
        {
            dal.Commit();
        }

        public void DBInitialization()
        {
            RemoveAllData();

            // Dar de alta unos profesores para poder usarlos luego
            AddTeacher(new Teacher("C/San Cristobal 10", "11111111A", "Prof1", 46022, "SSN11111111A"));
            AddTeacher(new Teacher("Av. La Informatica 20", "22222222B", "Prof2", 46022, "SSN22222222B"));
            AddTeacher(new Teacher("C/Sulfurosa 30", "33333333C", "Prof3", 46022, "SSN33333333B"));

            // Dar de alta unas aulas para poder usarlas luego
            Classroom aClassroom1 = new Classroom(2, "1P");
            AddClassroom(aClassroom1);
            Classroom aClassroom2 = new Classroom(10, "1A");
            AddClassroom(aClassroom2);
            Classroom aClassroom3 = new Classroom(5, "1G");
            AddClassroom(aClassroom3);


            // Dar de alta unos cursos para poder usarlos luego
            Course aCourse1 = new Course("Curso Introductorio Ingenieria Software", "Software Engineering");
            AddCourse(aCourse1);
            Course aCourse2 = new Course("Curso Introductorio de Estructuras de datos", "Data Structures");
            AddCourse(aCourse2);
            Course aCourse3 = new Course("Curso avanzado de Aerodinámica", "Advance aerodynamics");
            AddCourse(aCourse3);

            //Curso empezado en 03/25 Válido para prácticas y recuperación. Se podrán apuntar nuevos estudiantes
            DateTime startDateTime = new DateTime(2025, 3, 24, 9, 30, 0);
            DateTime endDate = new DateTime(2025, 5, 19);
            TaughtCourse aTaughtCourse1 = new TaughtCourse(endDate, 1, 3, 120, startDateTime, "Monday", 1500, aCourse1);//,aClassroom1);
            aTaughtCourse1.Classroom = aClassroom1;

            AddTaughtCourse(aTaughtCourse1);

            // Curso empezado en 04/24
            startDateTime = new DateTime(2024, 4, 15, 12, 0, 0);
            endDate = new DateTime(2024, 11, 30);
            TaughtCourse aTaughtCourse2 = new TaughtCourse(endDate, 2, 2, 120, startDateTime, "Wednesday", 1000, aCourse2);//,aClassroom2);
            aTaughtCourse2.Classroom = aClassroom2;

            AddTaughtCourse(aTaughtCourse2);

            // Curso empezado en 04/24
            startDateTime = new DateTime(2024, 4, 15, 12, 0, 0);
            endDate = new DateTime(2024, 11, 30);
            TaughtCourse aTaughtCourse3 = new TaughtCourse(endDate, 3, 2, 120, startDateTime, "Wednesday", 1000, aCourse3);//,aClassroom3);
            aTaughtCourse3.Classroom = aClassroom3;
            AddTaughtCourse(aTaughtCourse3);


        }

        /// <summary>
        /// Persiste un profesor
        /// </summary>
        /// <param name="teacher"></param>
        /// <exception cref="ServiceException"></exception>
        public void AddTeacher(Teacher teacher)
        {
            // Restricción: No puede haber dos personas con el mismo Id (dni)
            if (dal.GetById<Teacher>(teacher.Id) == null)
            {
                dal.Insert<Teacher>(teacher);
                dal.Commit();
            }
            else
                throw new ServiceException("There is another person with Id " + teacher.Id);
        }

        /// <summary>
        /// Persiste un aula
        /// </summary>
        /// <param name="Classroom"></param>
        /// <exception cref="ServiceException"></exception>
        public void AddClassroom(Classroom classroom)
        {
            // Restricción: No puede haber dos aulas con el mismo nombre
            if (!dal.GetWhere<Classroom>(x => x.Name == classroom.Name).Any())
            {
                dal.Insert<Classroom>(classroom);
                dal.Commit();
            }
            else
                throw new ServiceException("There is another classroom with Name " + classroom.Name);
        }

        /// <summary>
        /// Salva en la BD un curso
        /// </summary>
        /// <param name="course"></param>
        /// <exception cref="ServiceException"></exception>
        public void AddCourse(Course course)
        {
            // Restricción: No puede haber dos cursos con el mismo Name
            if (!dal.GetWhere<Course>(x => x.Name == course.Name).Any())
            {
                // Sólo se salva si no hay Name
                dal.Insert<Course>(course);
                dal.Commit();
            }
            else
                throw new ServiceException("Course with name " + course.Name + " already exists.");
        }

        /// <summary>
        /// Persiste el curso a impartir
        /// </summary>
        /// <param name="tcourse"></param>
        /// <exception cref="ServiceException"></exception>
        public void AddTaughtCourse(TaughtCourse tcourse)
        {
            // Restricción: No puede haber dos TaughtCourses con el mismo Id
            if (dal.GetById<TaughtCourse>(tcourse.Id) == null)
            {
                dal.Insert<TaughtCourse>(tcourse);
                dal.Commit();
            }
            else
                throw new ServiceException("Taught Course with Id " + tcourse.Id + " already exists.");
        }

        //
        // A partir de aquí vuestros métodos
        //

        //CASO 1
        public List<TaughtCourse> FindAllTaughtCourse()
        {
            return new List<TaughtCourse>(dal.GetAll<TaughtCourse>());
        }

        public List<Teacher> FindAllTeachers()
        {
            return new List<Teacher>(dal.GetAll<Teacher>());
        }

        public Teacher FindTeacherById(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentException("El ID no puede estar vacío", nameof(id));
            }

            return dal.GetById<Teacher>(id) ?? throw new ServiceException($"No se encontró un profesor con el ID: {id}");
        }


        public List<Teacher> FindTaughtCourseTeacherBySelection(TaughtCourse selected)
        {
            List<Teacher> Teachers = new List<Teacher>(dal.GetAll<Teacher>());
            List<Teacher> availableTeacher = new List<Teacher>();

            foreach (Teacher t in Teachers)
            {
                if (t.IsScheduleCompatibleWith(selected))
                {
                    availableTeacher.Add(t);
                }
            }

            return availableTeacher;
        }

        public void AssignTeacherToCourse(Teacher selected, TaughtCourse taughtCourse)
        {

            taughtCourse.Teachers.Add(selected);
            //dal.Insert<TaughtCourse>(taughtCourse);
            dal.Commit();
        }

        //CASO 3
        public List<TaughtCourse> FindAllTaughtCourseAfterToday()
        {
            List<TaughtCourse> taughtCourses = new List<TaughtCourse>(dal.GetAll<TaughtCourse>());
            List<TaughtCourse> afterToday = new List<TaughtCourse>();
            foreach (TaughtCourse tc in taughtCourses)
            {
                if (tc.isAfterToday())
                {
                    afterToday.Add(tc);
                }
            }
            return afterToday;
        }


        //los console.writeline tambien son pop-ups
        public string alumnoDni;

        public void GetDni()
        {
            //Console.WriteLine("Introduce el dni del alumno: ");
            alumnoDni = Console.ReadLine()?.Trim().ToUpper();
        }

        public List<Student> FindAllStudents()
        {
            return new List<Student>(dal.GetAll<Student>());
        }

        public Student StudentExistence()//preguntar si se puede unificar con EnrollStudentInCourse
        {
            Student student = dal.GetById<Student>(alumnoDni);
            if (student == null)
            {
                throw new ServiceException("No se encontró un estudiante con el DNI: " + alumnoDni);
                //pop-up pregunta
                Console.WriteLine("¿Desea registrar un nuevo estudiante con este DNI? (Si/No):");
                string response = Console.ReadLine();

                if (response.Trim().ToLower() == "Sí" || response.Trim().ToLower() == "Si")
                {
                    CreateStudent(student);
                }
                else if (response.Trim().ToLower() == "No")
                {
                    Console.WriteLine("No se ha creado un nuevo alumno");
                }
            }
            else
            {
                //pestaña mostrar datos student
                return student;
            }
        }

        //public void ShowStudentData(Student student) {
        //    Console.WriteLine("Mostrando datos ", student);
        //}

        public void CreateStudent(Student student)
        {
            //Si el alumno no existe, se crea uno nuevo y se solicita información adicional
            //meter en otro metodo "crearUsuario()"
            //Console.WriteLine("Creando nuevo alumno...");
            //Console.Write("Introduce el nombre del alumno: ");
            //string name = Console.ReadLine();
            //Console.Write("Introduce la dirección del alumno: ");
            //string address = Console.ReadLine();
            //Console.Write("Introduce el código postal del alumno: ");
            //int zipCode = int.Parse(Console.ReadLine());
            //Console.Write("Introduce el IBAN del alumno: ");
            //string iban = Console.ReadLine();

            student = new Student(student.Address, student.Id, student.Name, student.ZipCode, student.IBAN);

            //quieres añadir a esto alumno (si)
            dal.Insert<Student>(student);
            dal.Commit();

            //no lo quieres aladir
            //return;
        }

        public void EnrollStudentInCourse(TaughtCourse selected)
        {
            Student student = dal.GetById<Student>(alumnoDni);
            if (student == null) //el usuario existe
            {
                throw new ServiceException("No se encontró un estudiante con el DNI: " + alumnoDni);
            }
            else
            {
                if (AlreadyInCourse(selected, student)) //ya esta en el curso
                {
                    throw new ServiceException("El alumno ya está inscrito en este curso.");
                }
                else //no esta 
                {
                    if (!HasCourseCapacity(selected)) //no hay capacidad
                    {
                        throw new ServiceException("El curso no tiene plazas disponibles.");
                    }
                    else
                    {
                        CreateEnrollment(selected, student);
                    }
                }
            }
        }

        public Boolean AlreadyInCourse(TaughtCourse selected, Student student)
        {
            List<Enrollment> enrollments = new List<Enrollment>(dal.GetAll<Enrollment>().Where(e => e.TaughtCourse.Id == selected.Id));
            foreach (Enrollment enrollment in enrollments)
            {
                if (enrollment.Student.Id == student.Id)
                {
                    return true;
                }
            }
            return false;
        }

        public Boolean HasCourseCapacity(TaughtCourse selected)
        {
            if (selected.Classroom != null && selected.Enrollments.Count() < selected.Classroom.MaxCapacity)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public void CreateEnrollment(TaughtCourse selected, Student student)
        {
            Enrollment newEnrollment = new Enrollment(DateTime.Now, false, student, selected);
            selected.Enrollments.Add(newEnrollment);
            dal.Insert<Enrollment>(newEnrollment);
            dal.Commit();
        }


        //CASO 7

        // Asignar falta de asistencia

        public List<Absence> FindAllMyAbsences(Student student, TaughtCourse course)
        {
            // Buscar la inscripción del estudiante en el curso
            Enrollment enrollment = dal.GetAll<Enrollment>()
                .FirstOrDefault(e => e.Student.Id == student.Id && e.TaughtCourse.Id == course.Id);

            // Si no está inscrito, devolver una lista vacía
            if (enrollment == null)
            {
                return new List<Absence>(); 
            }

            // Devolver las ausencias asociadas a la inscripción
            return enrollment.Absences.ToList();
        }


        public void AssignAbsence(Student student, TaughtCourse course, DateTime absenceDate)
        {
            // Buscar la matrícula del estudiante en el curso
            Enrollment enrollment = dal.GetAll<Enrollment>()
                .FirstOrDefault(e => e.Student.Id == student.Id && e.TaughtCourse.Id == course.Id);

            if (enrollment == null)
            {
                throw new ServiceException("El estudiante no está inscrito en este curso.");
            }

            // Verificar que la fecha coincide con las sesiones del curso
            if (!course.TeachingDay.Equals(absenceDate.DayOfWeek.ToString(), StringComparison.OrdinalIgnoreCase))
            {
                throw new ServiceException("La fecha seleccionada no corresponde a un día de sesión del curso.");
            }

            // Verificar que la ausencia no esté duplicada
            if (enrollment.Absences.Any(a => a.Date.Date == absenceDate.Date))
            {
                throw new ServiceException("Ya existe una falta para este estudiante en la fecha indicada.");
            }

            // Crear y guardar la falta de asistencia
            Absence newAbsence = new Absence(absenceDate);
            enrollment.Absences.Add(newAbsence);
            dal.Insert<Absence>(newAbsence);
            dal.Commit();
        }



        public void RemoveAbsence(int absenceId)
        {
            // Buscar la falta de asistencia por su ID
            Absence absence = dal.GetById<Absence>(absenceId);
            if (absence == null)
            {
                throw new ServiceException("No se encontró una falta de asistencia con el ID indicado.");
            }

            // Eliminar la falta de asistencia
            dal.Delete<Absence>(absence);
            dal.Commit();
        }

    }
}
