﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GestAca.Entities;
using GestAca.Persistence;


namespace GestAca.Services
{
    public interface IGestAcaService
    {
        void RemoveAllData();
        void Commit();

        // Necesario para la inicialización de la BD
        void DBInitialization();
        void AddTeacher(Teacher teacher);
		void AddClassroom(Classroom classroom);
        void AddCourse(Course course);
        void AddTaughtCourse(TaughtCourse tcourse);


        //
        // A partir de aquí los necesarios para los CU solicitados
        //

        //Caso 1
        List<TaughtCourse> FindAllTaughtCourse();
        List<Teacher> FindAllTeachers();
        Teacher FindTeacherById(string id);
        List<Teacher> FindTaughtCourseTeacherBySelection(TaughtCourse selected);

        void AssignTeacherToCourse(Teacher selected, TaughtCourse taughtCourse);
        
        //Caso 3
        List<TaughtCourse> FindAllTaughtCourseAfterToday();
        void GetDni();
        List<Student> FindAllStudents();
        void CreateStudent(Student student);
        Student StudentExistence();
        void EnrollStudentInCourse(TaughtCourse selected);
        Boolean AlreadyInCourse(TaughtCourse selected, Student student);
        Boolean HasCourseCapacity(TaughtCourse selected);
        void CreateEnrollment(TaughtCourse selected, Student student);


        //Caso 7
        List<Absence> FindAllMyAbsences(Student student, TaughtCourse course);
        void AssignAbsence(Student student, TaughtCourse course, DateTime absenceDate);
        void RemoveAbsence(int absenceId);
          
    }
}
