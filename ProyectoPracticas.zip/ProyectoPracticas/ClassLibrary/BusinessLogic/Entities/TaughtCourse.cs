﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestAca.Entities
{
    public partial class TaughtCourse
    {
        public TaughtCourse() {
            Enrollments = new List<Enrollment>();
            Teachers = new List<Teacher>();
        }

        public TaughtCourse(DateTime EndDate, int Id, int Quotas, int SessionDuration, DateTime StartDateTime, string TeachingDay, int TotalPrice, Course course)//,Classroom classroom)
            :this() { 
            this.EndDate = EndDate;
            this.Id = Id;   
            this.Quotas = Quotas;
            this.SessionDuration = SessionDuration;
            this.StartDateTime = StartDateTime;
            this.TeachingDay = TeachingDay;
            this.TotalPrice = TotalPrice;

            Course = course;
          //  Classroom = classroom;
        }

        public Boolean isAfterToday() {
            return this.StartDateTime > DateTime.Now;
        }
    }
}
