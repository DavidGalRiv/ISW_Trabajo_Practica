﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestAca.Entities
{
   public abstract partial class Person
    {
        public Person() { }
        public Person(string Address, string Id, string Name, int ZipCode) {
            this.Address = Address;
            this.Id =Id;
            this.Name = Name;
            this.ZipCode = ZipCode;
        }
    }
}
