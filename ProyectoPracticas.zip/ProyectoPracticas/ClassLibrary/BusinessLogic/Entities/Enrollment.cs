﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestAca.Entities
{
    public partial class Enrollment
    {
        public Enrollment() { 
            Absences = new List<Absence>();
        }

        public Enrollment(DateTime EnrollmentDate, Boolean UniquePayment, Student student, TaughtCourse taughtCourse) :this() {
            this.CancellationDate = null;
            this.EnrollmentDate = EnrollmentDate;
            this.UniquePayment = UniquePayment;

            Student = student;
            TaughtCourse = taughtCourse;

            
        }
    }
}
