﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestAca.Entities
{
    public partial class Classroom
    {
        public Classroom() { 
            TaughtCourses = new List<TaughtCourse>();
        }

        public Classroom(int MaxCapacity, string Name) :this() {
            this.MaxCapacity = MaxCapacity;
            this.Name = Name;
        }
        public static int CountStudentsInClassroom(Classroom classroom)
        {
            return classroom.TaughtCourses
                            .SelectMany(course => course.Enrollments)
                            .Select(enrollment => enrollment.Student)
                            .Distinct()
                            .Count();
        }

        public List<Classroom> AvailableClassroom(TaughtCourse taughtCourse)
        {
            List<Classroom> availableClassroom = new List<Classroom>();

            foreach (TaughtCourse tc in this.TaughtCourses)
            {
                // Verificar que las aulas no se solapen en horario y cumplan con la capacidad
                if (tc.Classroom.Name == taughtCourse.Classroom.Name &&
                    CountStudentsInClassroom(tc.Classroom) < tc.Classroom.MaxCapacity &&
                    (tc.EndDate <= taughtCourse.StartDateTime || tc.StartDateTime >= taughtCourse.EndDate))
                {
                    availableClassroom.Add(tc.Classroom);
                }
            }

            return availableClassroom;
        }
    }
}
