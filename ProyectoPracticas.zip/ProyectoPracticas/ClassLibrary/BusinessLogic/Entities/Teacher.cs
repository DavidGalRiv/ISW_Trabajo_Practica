﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestAca.Entities
{
    public partial class Teacher : Person
    {
        public Teacher() {
            TaughtCourses = new List<TaughtCourse>();
        }

        public Teacher(string Address, string Id, string Name, int ZipCode, string Ssn)
            :base(Address, Id, Name, ZipCode){
            this.Ssn = Ssn;

            this.TaughtCourses = new List<TaughtCourse>();
        }
        public Boolean IsScheduleCompatibleWith(TaughtCourse taughtCourse)
        {
            foreach (TaughtCourse tc in this.TaughtCourses)
            {
                if (tc.TeachingDay == taughtCourse.TeachingDay)
                {// tc = viernes         taughtcourse = miercoles
                    if ((tc.StartDateTime <= taughtCourse.EndDate && tc.StartDateTime >= taughtCourse.StartDateTime)
                    || tc.EndDate > taughtCourse.StartDateTime
                    && tc.EndDate >= taughtCourse.EndDate)
                    {
                        return false;
                    } 
                }
                
            }
            return true;

        }
    }
}
