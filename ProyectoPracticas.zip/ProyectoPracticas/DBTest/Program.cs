﻿using System;
using System.Data.Entity.Validation;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GestAca.Entities;
using GestAca.Persistence;
using System.Net;
using System.Reflection.Emit;
using System.Xml.Linq;

namespace DBTest
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                new Program();
            }
            catch (Exception e)
            {
                printError(e);
            }
            Console.WriteLine("\nPulse una tecla para salir");
            Console.ReadLine();
        }

        static void printError(Exception e)
        {
            while (e != null)
            {
                if (e is DbEntityValidationException)
                {
                    DbEntityValidationException dbe = (DbEntityValidationException)e;

                    foreach (var eve in dbe.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Value: \"{1}\", Error: \"{2}\"",
                                ve.PropertyName,
                                eve.Entry.CurrentValues.GetValue<object>(ve.PropertyName),
                                ve.ErrorMessage);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("ERROR: " + e.Message);
                }
                e = e.InnerException;
            }
        }


        Program()
        {
            IDAL dal = new EntityFrameworkDAL(new GestAcaDbContext());

            CreateSampleDB(dal);
            PrintSampleDB(dal);
        }


        private void CreateSampleDB(IDAL dal)
        {
            dal.RemoveAllData();

            Console.WriteLine("CREANDO LOS DATOS Y ALMACENANDOLOS EN LA BD");
            Console.WriteLine("===========================================");

            Console.WriteLine("\n// CREACIÓN DE CURSOS");
            //public Course(string descr, string name)
            Course aCourse1 = new Course("Curso Introductorio Ingenieria Software", "Software Engineering");
            dal.Insert<Course>(aCourse1);
            dal.Commit();
            Course aCourse2 = new Course("Curso Introductorio de Estructuras de datos", "Data Structures");
            dal.Insert<Course>(aCourse2);
            dal.Commit();

            // Populate here the rest of the database
            // Add missing code here
            Console.WriteLine("\n// CREACIÓN DE CURSOS");
            Teacher aTeacher1 = new Teacher("C/ Redes 2", "00001", "Fede", 12345, "12345678");
            dal.Insert<Teacher>(aTeacher1);
            dal.Commit();
            Teacher aTeacher2 = new Teacher("C/ Software 3", "00002", "Gema", 54321, "87654321");
            dal.Insert<Teacher>(aTeacher2);
            dal.Commit();

            Console.WriteLine("\n// CREACIÓN DE CURSOS IMPARTIDOS");
            TaughtCourse aTaughtCourse1 = new TaughtCourse(DateTime.Now.AddMonths(3), 00003, 30, 120, DateTime.Now, "Lunes, Miércoles, Viernes", 800, aCourse1);
            dal.Insert<TaughtCourse>(aTaughtCourse1);
            dal.Commit();
            TaughtCourse aTaughtCourse2 = new TaughtCourse(DateTime.Now.AddMonths(3), 00004, 30, 120, DateTime.Now, "Lunes, Miércoles, Viernes", 800, aCourse2);
            dal.Insert<TaughtCourse>(aTaughtCourse2);
            dal.Commit();

            Console.WriteLine("\n// CREACIÓN DE ESTUDIANTES Y SUS INSCRIPCIONES");
            for (int i = 1; i <= 10; i++)
            {
                Student aStudent = new Student("Dirección" + i, "Estudiante" + i, "Nombre" + i, i, "IBAN" + i);
                dal.Insert<Student>(aStudent);
                Enrollment enrollment = new Enrollment(DateTime.Now, i % 2 == 0, aStudent, aTaughtCourse1);
                dal.Insert<Enrollment>(enrollment);
            }
            dal.Commit();

            Console.WriteLine("\n// CREACIÓN DE AULAS Y ASIGNACIÓN");
            Classroom c1 = new Classroom(60, "AULA 1G 1.1 (Edificio 1G)");
            Classroom c2 = new Classroom(30, "LAB. DSIC 9 (Edificio 1B)");
            dal.Insert<Classroom>(c1); 
            dal.Insert<Classroom>(c2); 
            dal.Commit();

            aTaughtCourse1.Classroom = c1;
            aTaughtCourse2.Classroom = c2;

            Console.WriteLine("\n// CREACIÓN DE AUSENCIAS");
            Student firstStudent = dal.GetAll<Student>().First();
            Enrollment firstEnrollment = dal.GetAll<Enrollment>().First();

            Absence a1 = new Absence(DateTime.Now.AddDays(-1));
            Absence a2 = new Absence(DateTime.Now.AddDays(-2));
            dal.Insert<Absence>(a1);
            dal.Insert<Absence>(a2);
            dal.Commit();

            Console.WriteLine("Datos de muestra creados y almacenados en la base de datos");
        }


        private void PrintSampleDB(IDAL dal)
        {
            Console.WriteLine("\n\nMOSTRANDO LOS DATOS DE LA BD");
            Console.WriteLine("============================\n");

            Console.WriteLine("\nCursos creados:");
            foreach (Course c in dal.GetAll<Course>())
                Console.WriteLine("   Name: " + c.Name + " Description: " + c.Description);

            // Show the rest of the database
            Console.WriteLine("\nProfesores creados:");
            foreach (Teacher t in dal.GetAll<Teacher>())
                Console.WriteLine("   ID: " + t.Id + " Name: " + t.Name);

            Console.WriteLine("\nImparticiones de cursos creados:");
            foreach(Course c in dal.GetAll<Course>())
            {
                Console.WriteLine("   Name: " + c.Name + " Description: " + c.Description);
                foreach (TaughtCourse tc in c.TaughtCourses)
                    Console.WriteLine("      ID: " + tc.Id + " START: " + tc.StartDateTime + " END: " + tc.EndDate);
            }

            Console.WriteLine("\nInscripciones por curso a impartir:");
            foreach (Course c in dal.GetAll<Course>())
            {
                Console.WriteLine("   Name: " + c.Name + " Description: " + c.Description);
                foreach (TaughtCourse tc in c.TaughtCourses)
                {
                    Console.WriteLine("      ID: " + tc.Id + " START: " + tc.StartDateTime + " END: " + tc.EndDate);
                    foreach(Enrollment en in tc.Enrollments)
                        Console.WriteLine("      ---> Student: " + en.Student.Name + " Enrollment Date: " + en.EnrollmentDate);
                }

            }

            Console.WriteLine("\nAulas creadas y sus asignaciones");
            foreach(Classroom o in dal.GetAll<Classroom>())
            {
                Console.WriteLine("   Name: " + o.Name + " Capacity: " + o.MaxCapacity);
                foreach(TaughtCourse tc in o.TaughtCourses)
                    Console.WriteLine("      CourseID: " + tc.Id + " START: " + tc.StartDateTime + " END: " + tc.EndDate + " People: " + tc.Enrollments.Count );
            }

            Console.WriteLine("\nFaltas de asistencia por alumno");
            foreach(Student s in dal.GetAll<Student>())
            {
                Console.WriteLine("   Student Name: " + s.Name);
                foreach(Enrollment en in s.Enrollments)
                {
                    Console.WriteLine("      Enrollment in: " + en.TaughtCourse.Id + " Course name: " + en.TaughtCourse.Course.Name + " Absences: " + en.Absences.Count);
                    foreach (Absence ab in en.Absences)
                        Console.WriteLine("         Date: " + ab.Date);
                }

            }
        }

    }

}
