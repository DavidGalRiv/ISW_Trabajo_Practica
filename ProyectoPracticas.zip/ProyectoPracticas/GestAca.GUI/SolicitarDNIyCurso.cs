﻿using GestAca.Entities;
using GestAca.GUI;
using GestAca.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace GestAca.GUI
{
    public partial class SolicitarDNIyCurso : SolicitarBase
    {
        private GestAcaCase7 gestAcaCase7;
        private DatosAlumno datosAlumno;
        private Student alumnoEncontrado;
        private TaughtCourse cursoEncontrado;
        public SolicitarDNIyCurso(IGestAcaService service) : base(service)
        {
            InitializeComponent();
            this.service = service;
            gestAcaCase7 = new GestAcaCase7(service, alumnoEncontrado, cursoEncontrado);
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.IntroduceDNI.Clear();
            this.IntroduceIdCurso.Clear();
            Close();
        }

        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            string dni = IntroduceDNI.Text.Trim().ToUpper();
            int curso;
            if (!int.TryParse(IntroduceIdCurso.Text, out curso))
            {
                MessageBox.Show("Por favor, introduzca un número válido para el curso.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (dni.Length != 9 || !ValidarDni(dni))
            {
                MessageBox.Show("DNI no válido. Introduzca un DNI correcto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            alumnoEncontrado = service.FindAllStudents().FirstOrDefault(st => st.Id == dni);
            cursoEncontrado = service.FindAllTaughtCourse().FirstOrDefault(tc => tc.Id == curso);
            //Comprobaciones

            //comprobar si el alumno existe
            if (alumnoEncontrado != null)
            {
                //si lo encuentra, comprueba que el curso existe
                if (cursoEncontrado != null)
                {
                    //comprobar si el alumno está en el curso
                    if (service.AlreadyInCourse(cursoEncontrado, alumnoEncontrado))
                    {
                        GestAcaCase7 gestAcaCase7 = new GestAcaCase7(service, alumnoEncontrado, cursoEncontrado);
                        //gestAcaCase7.SetStudent(alumnoEncontrado);
                        //gestAcaCase7.SetCourse(cursoEncontrado);
                        this.Hide();
                        gestAcaCase7.ShowDialog();
                        this.Show();
                    }
                    else
                    {
                        MessageBox.Show("El alumno no pertenece al curso indicado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Nos se ha encontrado un curso con ese identificador.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                MessageBox.Show("No se ha encontrado el alumno con ese DNI.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Introduce_DNI_TextChanged(object sender, EventArgs e)
        {
            //Coger el dni escrito por el usuario
            string dni = IntroduceDNI.Text.Trim().ToUpper(); // Leer texto y convertir a mayúsculas
            if (IntroduceDNI.TextLength == 9)
            {
                MensajeDNI.Visible = true;
                if (this.ValidarDni(dni))
                {
                    ConfirmButton.Enabled = true;
                    //Intento de poner el texto de aviso conforme a un dni válido o incorrecto
                    MensajeDNI.Text = "DNI válido.";
                    MensajeDNI.ForeColor = Color.Green;
                }
                else
                {
                    // Si el DNI no es válido, limpiar el TextBox
                    ConfirmButton.Enabled = false;
                    //Intento de poner el texto de aviso conforme a un dni válido o incorrecto
                    MensajeDNI.Text = "DNI no válido.";
                    MensajeDNI.ForeColor = Color.Red;
                }
            }
            else
            {
                MensajeDNI.Visible = false;
                ConfirmButton.Enabled = false;
            }
            //Si el dni está escrito correctamente dejará darle al botón de confirmar
        }
    }
}
