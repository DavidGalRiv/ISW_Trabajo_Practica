﻿using GestAca.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace GestAca.GUI
{
    public partial class GestAcaApp : Form
    {
        private IGestAcaService service;
        private SolicitarDNI solicitarDNI;
        private SolicitarDNIyCurso solicitarDNIyCurso;
        private DatosAlumno datosAlumno;
        private GestAcaBaseForm1 gestAcaBaseForm1;
        private GestAcaBaseForm2 gestAcaBaseForm2;
        //private GestAcaCase7 gestAcaCase7;
        private RegistrarAlumno registrarAlumno;
        public GestAcaApp(IGestAcaService service)
        {
            InitializeComponent();
            this.service = service;
            solicitarDNI = new SolicitarDNI(service);
            solicitarDNIyCurso = new SolicitarDNIyCurso(service);
            datosAlumno = new DatosAlumno(service);
            gestAcaBaseForm1 = new GestAcaBaseForm1(service);
            gestAcaBaseForm2 = new GestAcaBaseForm2(service);
            //gestAcaCase7 = new GestAcaCase7(service, null, null);
            registrarAlumno = new RegistrarAlumno(service);
        }

        private void MenuPrincipal_Load(object sender, EventArgs e)
        {
            service.FindAllTaughtCourseAfterToday();
            //cada curso encontrado asignarlo a un botón en la ventana principal, todos con la misma funcionalidad 
        }

        private void Caso_1_Button_Click(object sender, EventArgs e)
        {
            this.Hide();
            gestAcaBaseForm1.ButtonName = "Caso1Button";
            gestAcaBaseForm1.ShowDialog();
            this.Show();
        }

        private void Caso_3_Button_Click(object sender, EventArgs e)
        {
            this.Hide();
            gestAcaBaseForm2.ButtonName = "Caso3Button";
            gestAcaBaseForm2.ShowDialog();
            this.Show();
        }

        private void Caso_7_Button_Click(object sender, EventArgs e)
        {
            this.Hide();
            solicitarDNIyCurso.ShowDialog();
            this.Show();
        }
    }
}
