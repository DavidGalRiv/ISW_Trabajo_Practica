﻿using GestAca.Entities;
using GestAca.GUI;
using GestAca.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace GestAca.GUI
{
    public partial class GestAcaBaseForm2 : GestAcaBase
    {
        //IGestAcaService service;
        private SolicitarBase solicitarDNI;
        private DatosAlumno datosAlumno;
        private DatosCurso datosCurso;
        private TaughtCourse selectedCourse;

        public GestAcaBaseForm2(IGestAcaService service) : base(service)
        {
            InitializeComponent();
            //this.service = service;
            solicitarDNI = new SolicitarBase(service);
            datosAlumno = new DatosAlumno(service);
            datosCurso = new DatosCurso(service);
        }

        private void GestAcaBaseForm_Load(object sender, EventArgs e)
        {
            bindingSource1.Clear();
            ICollection<TaughtCourse> taughtCourses = service.FindAllTaughtCourse();

            foreach (TaughtCourse tc in taughtCourses)
            {
                bindingSource1.Add(new
                {
                    ds_EndDate = tc.EndDate,
                    ds_Id = tc.Id,
                    ds_Quotas = tc.Quotas,
                    ds_SessionDuration = tc.SessionDuration,
                    ds_StartDateTime = tc.StartDateTime,
                    ds_TeachingDay = tc.TeachingDay,
                    ds_TotalPrice = tc.TotalPrice
                });
            }
            dataGridView1.AutoGenerateColumns = true; // Generar columnas automáticamente
            //dataGridView1.DataSource = bindingSource1;
            //bindingSource1.ResetBindings(false);

        }

        //private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    int selectedRowCount = dataGridView1.Rows.GetRowCount(DataGridViewElementStates.Selected);

        //    if (selectedRowCount > 0) // Si hay al menos una fila seleccionada
        //    {
        //        // Tomar la primera fila seleccionada
        //        DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

        //        // Obtener el valor del Id del curso desde la celda correspondiente
        //        int selectedCourseId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

        //        // Buscar el curso correspondiente usando el servicio
        //        selectedCourse = service.FindAllTaughtCourse()
        //                                .FirstOrDefault(tc => tc.Id == selectedCourseId);

        //        if (selectedCourse != null)
        //        {
        //            // Mostrar un mensaje confirmando el curso seleccionado
        //            MessageBox.Show($"Curso seleccionado:\nID: {selectedCourse.Id}\nFecha de inicio: {selectedCourse.StartDateTime}",
        //                            "Curso Seleccionado",
        //                            MessageBoxButtons.OK,
        //                            MessageBoxIcon.Information);

        //            // Cambiar al formulario de solicitud de DNI
        //            solicitarDNI.SetCourse(selectedCourse);
        //            this.Hide();
        //            solicitarDNI.ShowDialog();
        //            this.Show();
        //        }
        //        else
        //        {
        //            MessageBox.Show("No se pudo encontrar el curso seleccionado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("No hay filas seleccionadas. Selecciona una fila para continuar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //    }
        //}

        private void Atras_Click_1(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
