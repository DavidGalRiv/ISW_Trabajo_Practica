﻿using GestAca.Entities;
using GestAca.Services;
using System;
using System.Linq;
using System.Windows.Forms;

namespace GestAca.GUI
{
    public partial class DatosAlumno : Form
    {
        private IGestAcaService service;
        private Student selectedStudent;
        private TaughtCourse selectedCourse;

        public DatosAlumno(IGestAcaService service)
        {
            InitializeComponent();
            this.service = service;
        }

        public void SetStudent(Student student) // Método para configurar estudiante
        {
            this.selectedStudent = student;
        }

        public void SetCourse(TaughtCourse course) // Método para configurar curso
        {
            this.selectedCourse = course;
        }

        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void Confirm_Button_Click(object sender, EventArgs e)
        {
            // Verificar si el estudiante ya está inscrito en el curso
            if (service.AlreadyInCourse(selectedCourse, selectedStudent))
            {
                MessageBox.Show($"El estudiante {selectedStudent.Id} ya está inscrito en el curso.",
                                "Inscripción Duplicada",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                this.Close();
                return;
            }

            // Verificar si el curso tiene capacidad
            if (!service.HasCourseCapacity(selectedCourse))
            {
                MessageBox.Show("El curso no tiene plazas disponibles.",
                                "Capacidad Completa",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                this.Close();
                return;
            }

            // Crear la inscripción
            service.CreateEnrollment(selectedCourse, selectedStudent);

            MessageBox.Show($"El estudiante {selectedStudent.Id} ha sido inscrito exitosamente en el curso.",
                            "Inscripción Exitosa",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);

            // Cerrar todas las ventanas relacionadas y volver al inicio
            Close();
        }



        private void DatosAlumnoOnLoad(object sender, EventArgs e)
        {
            // Mostrar los datos del alumno
            if (selectedStudent != null)
            {
                labelNombreAlumno.Text = selectedStudent.Name;
                labelDNIAlumno.Text = selectedStudent.Id;
                labelDireccionAlumno.Text = selectedStudent.Address;
                labelIBANAlumno.Text = selectedStudent.IBAN;
                labelZipCodeAlumno.Text = selectedStudent.ZipCode.ToString();
            }

            // Mostrar los datos del curso
            if (selectedCourse != null)
            {
                labelIdCurso.Text = selectedCourse.Id.ToString();
                labelStartDateTimeCurso.Text = selectedCourse.StartDateTime.ToShortDateString(); // Fecha de inicio
                labelEndDateCurso.Text = selectedCourse.EndDate.ToShortDateString(); // Fecha de fin
                labelQuotasCurso.Text = $"{selectedCourse.Quotas}"; // Número de plazas
                labelSessionDurationCurso.Text = $"{selectedCourse.SessionDuration} horas"; // Duración por sesión
                labelTeachingDayCurso.Text = selectedCourse.TeachingDay; // Día de enseñanza
                labelTotalPriceCurso.Text = $"{selectedCourse.TotalPrice:C}"; // Precio total (en formato moneda)
            }
            else
            {
                MessageBox.Show("No se ha proporcionado información del curso.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
