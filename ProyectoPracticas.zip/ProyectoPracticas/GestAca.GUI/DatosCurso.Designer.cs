﻿namespace GestAca.GUI
{
    partial class DatosCurso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labelTotalPriceCurso = new System.Windows.Forms.Label();
            this.labelTeachingDayCurso = new System.Windows.Forms.Label();
            this.labelStartDateTimeCurso = new System.Windows.Forms.Label();
            this.labelSessionDurationCurso = new System.Windows.Forms.Label();
            this.labelQuotasCurso = new System.Windows.Forms.Label();
            this.labelIdCurso = new System.Windows.Forms.Label();
            this.labelEndDateCurso = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ComboBoxProfesorAsociado = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.CancelButton = new System.Windows.Forms.Button();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelTotalPriceCurso);
            this.groupBox2.Controls.Add(this.labelTeachingDayCurso);
            this.groupBox2.Controls.Add(this.labelStartDateTimeCurso);
            this.groupBox2.Controls.Add(this.labelSessionDurationCurso);
            this.groupBox2.Controls.Add(this.labelQuotasCurso);
            this.groupBox2.Controls.Add(this.labelIdCurso);
            this.groupBox2.Controls.Add(this.labelEndDateCurso);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.ComboBoxProfesorAsociado);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(264, 258);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Datos del Curso";
            // 
            // labelTotalPriceCurso
            // 
            this.labelTotalPriceCurso.AutoSize = true;
            this.labelTotalPriceCurso.Location = new System.Drawing.Point(140, 200);
            this.labelTotalPriceCurso.Name = "labelTotalPriceCurso";
            this.labelTotalPriceCurso.Size = new System.Drawing.Size(41, 13);
            this.labelTotalPriceCurso.TabIndex = 28;
            this.labelTotalPriceCurso.Text = "label13";
            // 
            // labelTeachingDayCurso
            // 
            this.labelTeachingDayCurso.AutoSize = true;
            this.labelTeachingDayCurso.Location = new System.Drawing.Point(140, 175);
            this.labelTeachingDayCurso.Name = "labelTeachingDayCurso";
            this.labelTeachingDayCurso.Size = new System.Drawing.Size(41, 13);
            this.labelTeachingDayCurso.TabIndex = 27;
            this.labelTeachingDayCurso.Text = "label12";
            // 
            // labelStartDateTimeCurso
            // 
            this.labelStartDateTimeCurso.AutoSize = true;
            this.labelStartDateTimeCurso.Location = new System.Drawing.Point(140, 150);
            this.labelStartDateTimeCurso.Name = "labelStartDateTimeCurso";
            this.labelStartDateTimeCurso.Size = new System.Drawing.Size(41, 13);
            this.labelStartDateTimeCurso.TabIndex = 26;
            this.labelStartDateTimeCurso.Text = "label11";
            // 
            // labelSessionDurationCurso
            // 
            this.labelSessionDurationCurso.AutoSize = true;
            this.labelSessionDurationCurso.Location = new System.Drawing.Point(140, 125);
            this.labelSessionDurationCurso.Name = "labelSessionDurationCurso";
            this.labelSessionDurationCurso.Size = new System.Drawing.Size(41, 13);
            this.labelSessionDurationCurso.TabIndex = 25;
            this.labelSessionDurationCurso.Text = "label10";
            // 
            // labelQuotasCurso
            // 
            this.labelQuotasCurso.AutoSize = true;
            this.labelQuotasCurso.Location = new System.Drawing.Point(140, 100);
            this.labelQuotasCurso.Name = "labelQuotasCurso";
            this.labelQuotasCurso.Size = new System.Drawing.Size(35, 13);
            this.labelQuotasCurso.TabIndex = 24;
            this.labelQuotasCurso.Text = "label9";
            // 
            // labelIdCurso
            // 
            this.labelIdCurso.AutoSize = true;
            this.labelIdCurso.Location = new System.Drawing.Point(140, 75);
            this.labelIdCurso.Name = "labelIdCurso";
            this.labelIdCurso.Size = new System.Drawing.Size(35, 13);
            this.labelIdCurso.TabIndex = 23;
            this.labelIdCurso.Text = "label8";
            // 
            // labelEndDateCurso
            // 
            this.labelEndDateCurso.AutoSize = true;
            this.labelEndDateCurso.Location = new System.Drawing.Point(140, 50);
            this.labelEndDateCurso.Name = "labelEndDateCurso";
            this.labelEndDateCurso.Size = new System.Drawing.Size(35, 13);
            this.labelEndDateCurso.TabIndex = 22;
            this.labelEndDateCurso.Text = "label8";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "TotalPrice:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 175);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "TeachingDay:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "StartDateTime:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "SessionDuration:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Quotas: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Id:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "EndDate:";
            // 
            // ComboBoxProfesorAsociado
            // 
            this.ComboBoxProfesorAsociado.FormattingEnabled = true;
            this.ComboBoxProfesorAsociado.Location = new System.Drawing.Point(128, 17);
            this.ComboBoxProfesorAsociado.Name = "ComboBoxProfesorAsociado";
            this.ComboBoxProfesorAsociado.Size = new System.Drawing.Size(120, 21);
            this.ComboBoxProfesorAsociado.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Profesor Asociado:";
            // 
            // CancelButton
            // 
            this.CancelButton.BackColor = System.Drawing.Color.LightCoral;
            this.CancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CancelButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.CancelButton.Location = new System.Drawing.Point(118, 277);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 23);
            this.CancelButton.TabIndex = 13;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = false;
            this.CancelButton.Click += new System.EventHandler(this.Cancel_Button_Click);
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Location = new System.Drawing.Point(202, 277);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(75, 23);
            this.ConfirmButton.TabIndex = 14;
            this.ConfirmButton.Text = "Confirm";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.Confirm_Button_Click);
            // 
            // DatosCurso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 379);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.groupBox2);
            this.Name = "DatosCurso";
            this.Text = "Datos Curso";
            this.Load += new System.EventHandler(this.DatosCursoOnLoad);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox ComboBoxProfesorAsociado;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Label labelTotalPriceCurso;
        private System.Windows.Forms.Label labelTeachingDayCurso;
        private System.Windows.Forms.Label labelStartDateTimeCurso;
        private System.Windows.Forms.Label labelSessionDurationCurso;
        private System.Windows.Forms.Label labelQuotasCurso;
        private System.Windows.Forms.Label labelIdCurso;
        private System.Windows.Forms.Label labelEndDateCurso;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button ConfirmButton;
    }
}