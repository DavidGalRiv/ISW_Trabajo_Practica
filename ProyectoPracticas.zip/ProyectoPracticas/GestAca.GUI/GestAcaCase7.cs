﻿using GestAca.Entities;
using GestAca.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestAca.GUI
{
    public partial class GestAcaCase7 : Form
    {
        protected IGestAcaService service;
        private Student alumnoEncontrado;
        private TaughtCourse cursoEncontrado;
        public GestAcaCase7(IGestAcaService service, Student student, TaughtCourse taughtCourse)
        {
            InitializeComponent();
            this.service = service;
            alumnoEncontrado = student;
            cursoEncontrado = taughtCourse;
            LoadData();
        }

        public void SetStudent(Student student) // Método para configurar estudiante
        {
            this.alumnoEncontrado = student;
        }

        public void SetCourse(TaughtCourse course) // Método para configurar curso
        {
            this.cursoEncontrado = course;
        }

        private void LoadData()
        {
            ICollection<Absence> absences = service.FindAllMyAbsences(alumnoEncontrado, cursoEncontrado);

            bindingSource1.Clear();
            foreach (Absence ab in absences)
            {
                bindingSource1.Add(new
                {
                    ds_Id = ab.Id,
                    ds_Fecha = ab.Date
                });
            }

            dataGridView1.AutoGenerateColumns = true;
        }



        private void AgregarButton_Click(object sender, EventArgs e)
        {
            DateTime selectedDate = IndicarFechaAgregar.Value;
            DialogResult answer = MessageBox.Show(
                    $"Desea agregar la falta con fecha: {selectedDate}?",
                    "Agregar Falta",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
            if (answer == DialogResult.Yes) //lo agrega a la base de datos y saldrá en el grid
            {
                //comprobar que la fecha coincide con alguna sesión del curso y no está duplicada
                try
                {
                    service.AssignAbsence(alumnoEncontrado, cursoEncontrado, selectedDate);
                    MessageBox.Show("Falta de asistencia agregada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData(); // Recargar la lista
                }
                catch (ServiceException ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void QuitarButton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una falta para eliminar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int absenceId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["Id_Falta"].Value);
            DateTime fecha = Convert.ToDateTime(dataGridView1.SelectedRows[0].Cells["Fecha"].Value);

            DialogResult answer = MessageBox.Show(
                $"Desea eliminar la falta con fecha: {fecha.ToShortDateString()}?",
                "Quitar Falta",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (answer == DialogResult.Yes)
            {
                try
                {
                    service.RemoveAbsence(absenceId);
                    MessageBox.Show("Falta de asistencia eliminada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData(); // Recargar la lista
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al eliminar la falta: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            Close();
        }

        private void GestAcaCase7_Load(object sender, EventArgs e)
        {
            if (alumnoEncontrado != null)
            {
                labelDNIAlumno.Text = alumnoEncontrado.Id;
            }

            // Mostrar los datos del curso
            if (cursoEncontrado != null)
            {
                labelCurso.Text = cursoEncontrado.Id.ToString();
            }
            else
            {
                MessageBox.Show("No se ha proporcionado información del curso.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
