﻿using GestAca.Entities;
using GestAca.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace GestAca.GUI
{
    public partial class DatosCurso : Form
    {
        private IGestAcaService service;
        private TaughtCourse selectedCourse;

        public DatosCurso(IGestAcaService service)
        {
            InitializeComponent();
            this.service = service;
        }

        public void SetCourse(TaughtCourse course) // Método para configurar curso
        {
            this.selectedCourse = course;
        }

        private void DatosCursoOnLoad(object sender, EventArgs e)
        {
            if (selectedCourse != null)
            {
                labelEndDateCurso.Text = selectedCourse.EndDate.ToString();
                labelIdCurso.Text = selectedCourse.Id.ToString();
                labelQuotasCurso.Text = selectedCourse.Quotas.ToString();
                labelSessionDurationCurso.Text = selectedCourse.SessionDuration.ToString();
                labelStartDateTimeCurso.Text = selectedCourse.StartDateTime.ToString();
                labelTeachingDayCurso.Text = selectedCourse.TeachingDay;
                labelTotalPriceCurso.Text = selectedCourse.TotalPrice.ToString();

                try
                {
                    List<Teacher> eligibleTeachers = service.FindTaughtCourseTeacherBySelection(selectedCourse);

                    List<Teacher> assignedTeachers = eligibleTeachers
                        .Where(teacher => selectedCourse.Teachers.Any(t => t.Id == teacher.Id))
                        .ToList();

                    List<Teacher> availableTeachers = eligibleTeachers
                        .Where(teacher => !assignedTeachers.Any(at => at.Id == teacher.Id))
                        .ToList();

                    ComboBoxProfesorAsociado.Items.Clear();

                    foreach (Teacher teacher in availableTeachers)
                    {
                        ComboBoxProfesorAsociado.Items.Add($"{teacher.Id} - {teacher.Name}");
                    }

                    ComboBoxProfesorAsociado.Text = string.Empty; 
                    ComboBoxProfesorAsociado.SelectedIndex = -1; 
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar los profesores: {ex.Message}",
                                    "Error",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                }
            }
        }

        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void Confirm_Button_Click(object sender, EventArgs e)
        {
            if (ComboBoxProfesorAsociado.SelectedItem != null)
            {
                string selectedTeacherString = ComboBoxProfesorAsociado.SelectedItem.ToString();
                string selectedTeacherId = selectedTeacherString.Split(' ')[0];

                Teacher selectedTeacher = service.FindTeacherById(selectedTeacherId);

                if (selectedTeacher != null && selectedCourse != null)
                {
                    try
                    {
                        service.AssignTeacherToCourse(selectedTeacher, selectedCourse);

                        MessageBox.Show($"El profesor {selectedTeacher.Name} ha sido asignado al curso.",
                                        "Asignación Exitosa",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);

                        Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al asignar el profesor: {ex.Message}",
                                        "Error",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("No se pudo asignar el profesor seleccionado.",
                                    "Error",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Seleccione un profesor antes de confirmar.",
                                "Advertencia",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }
        }
    }
}
