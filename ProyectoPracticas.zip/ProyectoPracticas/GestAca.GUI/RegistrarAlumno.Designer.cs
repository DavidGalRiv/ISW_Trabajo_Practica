﻿namespace GestAca.GUI
{
    partial class RegistrarAlumno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ZipCodeAlumno = new System.Windows.Forms.Label();
            this.NombreAlumno = new System.Windows.Forms.Label();
            this.DNIAlumno = new System.Windows.Forms.Label();
            this.DireccionAlumno = new System.Windows.Forms.Label();
            this.IBANAlumno = new System.Windows.Forms.Label();
            this.NombreTextBox = new System.Windows.Forms.TextBox();
            this.DNITextBox = new System.Windows.Forms.TextBox();
            this.DireccionTextBox = new System.Windows.Forms.TextBox();
            this.IBANTextBox = new System.Windows.Forms.TextBox();
            this.ZipCodeTextBox = new System.Windows.Forms.TextBox();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ZipCodeTextBox);
            this.groupBox1.Controls.Add(this.IBANTextBox);
            this.groupBox1.Controls.Add(this.DireccionTextBox);
            this.groupBox1.Controls.Add(this.DNITextBox);
            this.groupBox1.Controls.Add(this.NombreTextBox);
            this.groupBox1.Controls.Add(this.ZipCodeAlumno);
            this.groupBox1.Controls.Add(this.NombreAlumno);
            this.groupBox1.Controls.Add(this.DNIAlumno);
            this.groupBox1.Controls.Add(this.DireccionAlumno);
            this.groupBox1.Controls.Add(this.IBANAlumno);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(260, 162);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos del Alumno";
            // 
            // ZipCodeAlumno
            // 
            this.ZipCodeAlumno.AutoSize = true;
            this.ZipCodeAlumno.Location = new System.Drawing.Point(6, 120);
            this.ZipCodeAlumno.Name = "ZipCodeAlumno";
            this.ZipCodeAlumno.Size = new System.Drawing.Size(50, 13);
            this.ZipCodeAlumno.TabIndex = 12;
            this.ZipCodeAlumno.Text = "ZipCode:";
            // 
            // NombreAlumno
            // 
            this.NombreAlumno.AutoSize = true;
            this.NombreAlumno.Location = new System.Drawing.Point(6, 20);
            this.NombreAlumno.Name = "NombreAlumno";
            this.NombreAlumno.Size = new System.Drawing.Size(50, 13);
            this.NombreAlumno.TabIndex = 0;
            this.NombreAlumno.Text = "Nombre: ";
            // 
            // DNIAlumno
            // 
            this.DNIAlumno.AutoSize = true;
            this.DNIAlumno.Location = new System.Drawing.Point(6, 45);
            this.DNIAlumno.Name = "DNIAlumno";
            this.DNIAlumno.Size = new System.Drawing.Size(32, 13);
            this.DNIAlumno.TabIndex = 1;
            this.DNIAlumno.Text = "DNI: ";
            // 
            // DireccionAlumno
            // 
            this.DireccionAlumno.AutoSize = true;
            this.DireccionAlumno.Location = new System.Drawing.Point(6, 70);
            this.DireccionAlumno.Name = "DireccionAlumno";
            this.DireccionAlumno.Size = new System.Drawing.Size(55, 13);
            this.DireccionAlumno.TabIndex = 6;
            this.DireccionAlumno.Text = "Dirección:";
            // 
            // IBANAlumno
            // 
            this.IBANAlumno.AutoSize = true;
            this.IBANAlumno.Location = new System.Drawing.Point(6, 95);
            this.IBANAlumno.Name = "IBANAlumno";
            this.IBANAlumno.Size = new System.Drawing.Size(38, 13);
            this.IBANAlumno.TabIndex = 7;
            this.IBANAlumno.Text = "IBAN: ";
            // 
            // NombreTextBox
            // 
            this.NombreTextBox.Location = new System.Drawing.Point(139, 20);
            this.NombreTextBox.Name = "NombreTextBox";
            this.NombreTextBox.Size = new System.Drawing.Size(100, 20);
            this.NombreTextBox.TabIndex = 13;
            // 
            // DNITextBox
            // 
            this.DNITextBox.Location = new System.Drawing.Point(139, 45);
            this.DNITextBox.MaxLength = 9;
            this.DNITextBox.Name = "DNITextBox";
            this.DNITextBox.Size = new System.Drawing.Size(100, 20);
            this.DNITextBox.TabIndex = 14;
            // 
            // DireccionTextBox
            // 
            this.DireccionTextBox.Location = new System.Drawing.Point(139, 70);
            this.DireccionTextBox.Name = "DireccionTextBox";
            this.DireccionTextBox.Size = new System.Drawing.Size(100, 20);
            this.DireccionTextBox.TabIndex = 15;
            // 
            // IBANTextBox
            // 
            this.IBANTextBox.Location = new System.Drawing.Point(139, 95);
            this.IBANTextBox.Name = "IBANTextBox";
            this.IBANTextBox.Size = new System.Drawing.Size(100, 20);
            this.IBANTextBox.TabIndex = 16;
            // 
            // ZipCodeTextBox
            // 
            this.ZipCodeTextBox.Location = new System.Drawing.Point(139, 120);
            this.ZipCodeTextBox.Name = "ZipCodeTextBox";
            this.ZipCodeTextBox.Size = new System.Drawing.Size(100, 20);
            this.ZipCodeTextBox.TabIndex = 17;
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Location = new System.Drawing.Point(197, 199);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(75, 23);
            this.ConfirmButton.TabIndex = 12;
            this.ConfirmButton.Text = "Confirm";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.Confirm_Button_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.BackColor = System.Drawing.Color.LightCoral;
            this.CancelButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.CancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CancelButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.CancelButton.Location = new System.Drawing.Point(107, 199);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 23);
            this.CancelButton.TabIndex = 13;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = false;
            this.CancelButton.Click += new System.EventHandler(this.Cancel_Button_Click);
            // 
            // RegistrarAlumno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.groupBox1);
            this.Name = "RegistrarAlumno";
            this.Text = "RegistrarAlumno";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox ZipCodeTextBox;
        private System.Windows.Forms.TextBox IBANTextBox;
        private System.Windows.Forms.TextBox DireccionTextBox;
        private System.Windows.Forms.TextBox DNITextBox;
        private System.Windows.Forms.TextBox NombreTextBox;
        private System.Windows.Forms.Label ZipCodeAlumno;
        private System.Windows.Forms.Label NombreAlumno;
        private System.Windows.Forms.Label DNIAlumno;
        private System.Windows.Forms.Label DireccionAlumno;
        private System.Windows.Forms.Label IBANAlumno;
        private System.Windows.Forms.Button ConfirmButton;
        private System.Windows.Forms.Button CancelButton;
    }
}