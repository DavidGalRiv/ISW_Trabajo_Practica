﻿using GestAca.Persistence;
using GestAca.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace GestAca.GUI
{
     static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            IGestAcaService service = new GestAcaService(new EntityFrameworkDAL(new GestAcaDbContext()));
            service.DBInitialization();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GestAcaApp(service));
        }
    }
}
