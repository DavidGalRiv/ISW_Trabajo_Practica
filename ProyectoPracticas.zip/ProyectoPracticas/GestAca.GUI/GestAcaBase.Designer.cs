﻿namespace GestAca.GUI
{
    partial class GestAcaBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Atras = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.EndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quotas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SessionDuration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TeachingDay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // Atras
            // 
            this.Atras.Location = new System.Drawing.Point(907, 382);
            this.Atras.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Atras.Name = "Atras";
            this.Atras.Size = new System.Drawing.Size(100, 42);
            this.Atras.TabIndex = 4;
            this.Atras.Text = "Atras";
            this.Atras.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EndDate,
            this.Id,
            this.Quotas,
            this.SessionDuration,
            this.StartDateTime,
            this.TeachingDay,
            this.TotalPrice});
            this.dataGridView1.DataSource = this.bindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(16, 15);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(991, 286);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // EndDate
            // 
            this.EndDate.DataPropertyName = "ds_EndDate";
            this.EndDate.HeaderText = "EndDate";
            this.EndDate.MinimumWidth = 8;
            this.EndDate.Name = "EndDate";
            this.EndDate.ReadOnly = true;
            this.EndDate.Width = 150;
            // 
            // Id
            // 
            this.Id.DataPropertyName = "ds_Id";
            this.Id.HeaderText = "Id";
            this.Id.MinimumWidth = 8;
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            this.Id.Width = 150;
            // 
            // Quotas
            // 
            this.Quotas.DataPropertyName = "ds_Quotas";
            this.Quotas.HeaderText = "Quotas";
            this.Quotas.MinimumWidth = 8;
            this.Quotas.Name = "Quotas";
            this.Quotas.ReadOnly = true;
            this.Quotas.Width = 150;
            // 
            // SessionDuration
            // 
            this.SessionDuration.DataPropertyName = "ds_SessionDuration";
            this.SessionDuration.HeaderText = "SessionDuration";
            this.SessionDuration.MinimumWidth = 8;
            this.SessionDuration.Name = "SessionDuration";
            this.SessionDuration.ReadOnly = true;
            this.SessionDuration.Width = 150;
            // 
            // StartDateTime
            // 
            this.StartDateTime.DataPropertyName = "ds_StartDateTime";
            this.StartDateTime.HeaderText = "StartDateTime";
            this.StartDateTime.MinimumWidth = 8;
            this.StartDateTime.Name = "StartDateTime";
            this.StartDateTime.ReadOnly = true;
            this.StartDateTime.Width = 150;
            // 
            // TeachingDay
            // 
            this.TeachingDay.DataPropertyName = "ds_TeachingDay";
            this.TeachingDay.HeaderText = "TeachingDay";
            this.TeachingDay.MinimumWidth = 8;
            this.TeachingDay.Name = "TeachingDay";
            this.TeachingDay.ReadOnly = true;
            this.TeachingDay.Width = 150;
            // 
            // TotalPrice
            // 
            this.TotalPrice.DataPropertyName = "ds_TotalPrice";
            this.TotalPrice.HeaderText = "TotalPrice";
            this.TotalPrice.MinimumWidth = 8;
            this.TotalPrice.Name = "TotalPrice";
            this.TotalPrice.ReadOnly = true;
            this.TotalPrice.Width = 150;
            // 
            // GestAcaBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.Atras);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "GestAcaBase";
            this.Text = "GestAcaBase";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridViewTextBoxColumn EndDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quotas;
        private System.Windows.Forms.DataGridViewTextBoxColumn SessionDuration;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn TeachingDay;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalPrice;
        private System.Windows.Forms.BindingSource bindingSource1;
        protected System.Windows.Forms.DataGridView dataGridView1;
        protected System.Windows.Forms.Button Atras;
    }
}