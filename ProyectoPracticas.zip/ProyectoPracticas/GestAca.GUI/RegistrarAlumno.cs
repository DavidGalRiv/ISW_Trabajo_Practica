﻿using GestAca.Entities;
using GestAca.Services;
using System;
using System;
using System.Linq;
using System.Windows.Forms;

namespace GestAca.GUI
{
    public partial class RegistrarAlumno : Form
    {
        private IGestAcaService service;
        private TaughtCourse selected;

        public RegistrarAlumno(IGestAcaService service)
        {
            InitializeComponent();
            this.service = service;
        }

        public void SetDNI(string dni)
        {
            DNITextBox.Text = dni;
            DNITextBox.Enabled = false; // Bloquear el campo para evitar cambios
        }

        public void SetCourse(TaughtCourse selected) // Método para recibir el curso
        {
            this.selected = selected;
        }

        private void Confirm_Button_Click(object sender, EventArgs e)
        {
            string nombre = NombreTextBox.Text.Trim();
            string dni = DNITextBox.Text.Trim();
            string direccion = DireccionTextBox.Text.Trim();
            string iban = IBANTextBox.Text.Trim();
            string zipCode = ZipCodeTextBox.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(dni) ||
                string.IsNullOrEmpty(direccion) || string.IsNullOrEmpty(iban) ||
                string.IsNullOrEmpty(zipCode))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Student newStudent = new Student
                {
                    Name = nombre,
                    Id = dni,
                    Address = direccion,
                    IBAN = iban,
                    ZipCode = int.Parse(zipCode)
                };
                service.CreateStudent(newStudent);
                MessageBox.Show("Alumno registrado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK; // Indicar éxito al cerrar el formulario
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al registrar el alumno: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; // Indicar cancelación al cerrar
            this.Close();
        }
    }
}
