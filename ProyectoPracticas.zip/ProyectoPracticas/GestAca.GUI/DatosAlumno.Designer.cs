﻿namespace GestAca.GUI
{
    partial class DatosAlumno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NombreAlumno = new System.Windows.Forms.Label();
            this.DNIAlumno = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.DireccionAlumno = new System.Windows.Forms.Label();
            this.IBANAlumno = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelNombreAlumno = new System.Windows.Forms.Label();
            this.labelDNIAlumno = new System.Windows.Forms.Label();
            this.labelDireccionAlumno = new System.Windows.Forms.Label();
            this.labelIBANAlumno = new System.Windows.Forms.Label();
            this.labelEndDateCurso = new System.Windows.Forms.Label();
            this.ZipCodeAlumno = new System.Windows.Forms.Label();
            this.labelZipCodeAlumno = new System.Windows.Forms.Label();
            this.labelIdCurso = new System.Windows.Forms.Label();
            this.labelQuotasCurso = new System.Windows.Forms.Label();
            this.labelSessionDurationCurso = new System.Windows.Forms.Label();
            this.labelStartDateTimeCurso = new System.Windows.Forms.Label();
            this.labelTeachingDayCurso = new System.Windows.Forms.Label();
            this.labelTotalPriceCurso = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // NombreAlumno
            // 
            this.NombreAlumno.AutoSize = true;
            this.NombreAlumno.Location = new System.Drawing.Point(6, 20);
            this.NombreAlumno.Name = "NombreAlumno";
            this.NombreAlumno.Size = new System.Drawing.Size(50, 13);
            this.NombreAlumno.TabIndex = 0;
            this.NombreAlumno.Text = "Nombre: ";
            // 
            // DNIAlumno
            // 
            this.DNIAlumno.AutoSize = true;
            this.DNIAlumno.Location = new System.Drawing.Point(6, 45);
            this.DNIAlumno.Name = "DNIAlumno";
            this.DNIAlumno.Size = new System.Drawing.Size(32, 13);
            this.DNIAlumno.TabIndex = 1;
            this.DNIAlumno.Text = "DNI: ";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(202, 412);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 25);
            this.button1.TabIndex = 4;
            this.button1.Text = "Confirm";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Confirm_Button_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCoral;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(126, 412);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(70, 25);
            this.button2.TabIndex = 5;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Cancel_Button_Click);
            // 
            // DireccionAlumno
            // 
            this.DireccionAlumno.AutoSize = true;
            this.DireccionAlumno.Location = new System.Drawing.Point(6, 70);
            this.DireccionAlumno.Name = "DireccionAlumno";
            this.DireccionAlumno.Size = new System.Drawing.Size(55, 13);
            this.DireccionAlumno.TabIndex = 6;
            this.DireccionAlumno.Text = "Dirección:";
            // 
            // IBANAlumno
            // 
            this.IBANAlumno.AutoSize = true;
            this.IBANAlumno.Location = new System.Drawing.Point(6, 95);
            this.IBANAlumno.Name = "IBANAlumno";
            this.IBANAlumno.Size = new System.Drawing.Size(38, 13);
            this.IBANAlumno.TabIndex = 7;
            this.IBANAlumno.Text = "IBAN: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelZipCodeAlumno);
            this.groupBox1.Controls.Add(this.ZipCodeAlumno);
            this.groupBox1.Controls.Add(this.labelIBANAlumno);
            this.groupBox1.Controls.Add(this.labelDireccionAlumno);
            this.groupBox1.Controls.Add(this.labelDNIAlumno);
            this.groupBox1.Controls.Add(this.labelNombreAlumno);
            this.groupBox1.Controls.Add(this.NombreAlumno);
            this.groupBox1.Controls.Add(this.DNIAlumno);
            this.groupBox1.Controls.Add(this.DireccionAlumno);
            this.groupBox1.Controls.Add(this.IBANAlumno);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(260, 162);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos del Alumno";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelTotalPriceCurso);
            this.groupBox2.Controls.Add(this.labelTeachingDayCurso);
            this.groupBox2.Controls.Add(this.labelStartDateTimeCurso);
            this.groupBox2.Controls.Add(this.labelSessionDurationCurso);
            this.groupBox2.Controls.Add(this.labelQuotasCurso);
            this.groupBox2.Controls.Add(this.labelIdCurso);
            this.groupBox2.Controls.Add(this.labelEndDateCurso);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 181);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(260, 203);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Datos del Curso";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "EndDate:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Id:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quotas: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "SessionDuration:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "StartDateTime:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "TeachingDay:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 170);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "TotalPrice:";
            // 
            // labelNombreAlumno
            // 
            this.labelNombreAlumno.AutoSize = true;
            this.labelNombreAlumno.Location = new System.Drawing.Point(140, 20);
            this.labelNombreAlumno.Name = "labelNombreAlumno";
            this.labelNombreAlumno.Size = new System.Drawing.Size(34, 13);
            this.labelNombreAlumno.TabIndex = 8;
            this.labelNombreAlumno.Text = "Text1";
            // 
            // labelDNIAlumno
            // 
            this.labelDNIAlumno.AutoSize = true;
            this.labelDNIAlumno.Location = new System.Drawing.Point(140, 45);
            this.labelDNIAlumno.Name = "labelDNIAlumno";
            this.labelDNIAlumno.Size = new System.Drawing.Size(34, 13);
            this.labelDNIAlumno.TabIndex = 9;
            this.labelDNIAlumno.Text = "Text2";
            // 
            // labelDireccionAlumno
            // 
            this.labelDireccionAlumno.AutoSize = true;
            this.labelDireccionAlumno.Location = new System.Drawing.Point(140, 70);
            this.labelDireccionAlumno.Name = "labelDireccionAlumno";
            this.labelDireccionAlumno.Size = new System.Drawing.Size(35, 13);
            this.labelDireccionAlumno.TabIndex = 10;
            this.labelDireccionAlumno.Text = "label8";
            // 
            // labelIBANAlumno
            // 
            this.labelIBANAlumno.AutoSize = true;
            this.labelIBANAlumno.Location = new System.Drawing.Point(140, 95);
            this.labelIBANAlumno.Name = "labelIBANAlumno";
            this.labelIBANAlumno.Size = new System.Drawing.Size(35, 13);
            this.labelIBANAlumno.TabIndex = 11;
            this.labelIBANAlumno.Text = "label8";
            // 
            // labelEndDateCurso
            // 
            this.labelEndDateCurso.AutoSize = true;
            this.labelEndDateCurso.Location = new System.Drawing.Point(140, 20);
            this.labelEndDateCurso.Name = "labelEndDateCurso";
            this.labelEndDateCurso.Size = new System.Drawing.Size(35, 13);
            this.labelEndDateCurso.TabIndex = 7;
            this.labelEndDateCurso.Text = "label8";
            // 
            // ZipCodeAlumno
            // 
            this.ZipCodeAlumno.AutoSize = true;
            this.ZipCodeAlumno.Location = new System.Drawing.Point(6, 120);
            this.ZipCodeAlumno.Name = "ZipCodeAlumno";
            this.ZipCodeAlumno.Size = new System.Drawing.Size(50, 13);
            this.ZipCodeAlumno.TabIndex = 12;
            this.ZipCodeAlumno.Text = "ZipCode:";
            // 
            // labelZipCodeAlumno
            // 
            this.labelZipCodeAlumno.AutoSize = true;
            this.labelZipCodeAlumno.Location = new System.Drawing.Point(140, 120);
            this.labelZipCodeAlumno.Name = "labelZipCodeAlumno";
            this.labelZipCodeAlumno.Size = new System.Drawing.Size(35, 13);
            this.labelZipCodeAlumno.TabIndex = 13;
            this.labelZipCodeAlumno.Text = "label9";
            // 
            // labelIdCurso
            // 
            this.labelIdCurso.AutoSize = true;
            this.labelIdCurso.Location = new System.Drawing.Point(140, 45);
            this.labelIdCurso.Name = "labelIdCurso";
            this.labelIdCurso.Size = new System.Drawing.Size(35, 13);
            this.labelIdCurso.TabIndex = 8;
            this.labelIdCurso.Text = "label8";
            // 
            // labelQuotasCurso
            // 
            this.labelQuotasCurso.AutoSize = true;
            this.labelQuotasCurso.Location = new System.Drawing.Point(140, 70);
            this.labelQuotasCurso.Name = "labelQuotasCurso";
            this.labelQuotasCurso.Size = new System.Drawing.Size(35, 13);
            this.labelQuotasCurso.TabIndex = 9;
            this.labelQuotasCurso.Text = "label9";
            // 
            // labelSessionDurationCurso
            // 
            this.labelSessionDurationCurso.AutoSize = true;
            this.labelSessionDurationCurso.Location = new System.Drawing.Point(140, 95);
            this.labelSessionDurationCurso.Name = "labelSessionDurationCurso";
            this.labelSessionDurationCurso.Size = new System.Drawing.Size(41, 13);
            this.labelSessionDurationCurso.TabIndex = 10;
            this.labelSessionDurationCurso.Text = "label10";
            // 
            // labelStartDateTimeCurso
            // 
            this.labelStartDateTimeCurso.AutoSize = true;
            this.labelStartDateTimeCurso.Location = new System.Drawing.Point(140, 120);
            this.labelStartDateTimeCurso.Name = "labelStartDateTimeCurso";
            this.labelStartDateTimeCurso.Size = new System.Drawing.Size(41, 13);
            this.labelStartDateTimeCurso.TabIndex = 11;
            this.labelStartDateTimeCurso.Text = "label11";
            // 
            // labelTeachingDayCurso
            // 
            this.labelTeachingDayCurso.AutoSize = true;
            this.labelTeachingDayCurso.Location = new System.Drawing.Point(140, 145);
            this.labelTeachingDayCurso.Name = "labelTeachingDayCurso";
            this.labelTeachingDayCurso.Size = new System.Drawing.Size(41, 13);
            this.labelTeachingDayCurso.TabIndex = 12;
            this.labelTeachingDayCurso.Text = "label12";
            // 
            // labelTotalPriceCurso
            // 
            this.labelTotalPriceCurso.AutoSize = true;
            this.labelTotalPriceCurso.Location = new System.Drawing.Point(140, 170);
            this.labelTotalPriceCurso.Name = "labelTotalPriceCurso";
            this.labelTotalPriceCurso.Size = new System.Drawing.Size(41, 13);
            this.labelTotalPriceCurso.TabIndex = 13;
            this.labelTotalPriceCurso.Text = "label13";
            // 
            // DatosAlumno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 453);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "DatosAlumno";
            this.Text = "Datos Alumno";
            this.Load += new System.EventHandler(this.DatosAlumnoOnLoad);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label NombreAlumno;
        private System.Windows.Forms.Label DNIAlumno;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label DireccionAlumno;
        private System.Windows.Forms.Label IBANAlumno;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelDNIAlumno;
        private System.Windows.Forms.Label labelNombreAlumno;
        private System.Windows.Forms.Label labelZipCodeAlumno;
        private System.Windows.Forms.Label ZipCodeAlumno;
        private System.Windows.Forms.Label labelIBANAlumno;
        private System.Windows.Forms.Label labelDireccionAlumno;
        private System.Windows.Forms.Label labelTotalPriceCurso;
        private System.Windows.Forms.Label labelTeachingDayCurso;
        private System.Windows.Forms.Label labelStartDateTimeCurso;
        private System.Windows.Forms.Label labelSessionDurationCurso;
        private System.Windows.Forms.Label labelQuotasCurso;
        private System.Windows.Forms.Label labelIdCurso;
        private System.Windows.Forms.Label labelEndDateCurso;
    }
}