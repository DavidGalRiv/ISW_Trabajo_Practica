﻿namespace GestAca.GUI
{
    partial class GestAcaApp
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Caso1Button = new System.Windows.Forms.Button();
            this.Caso3Button = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Caso7Button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(15, 12);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.Caso1Button);
            this.flowLayoutPanel1.Controls.Add(this.Caso3Button);
            this.flowLayoutPanel1.Controls.Add(this.button1);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 38);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(905, 515);
            this.flowLayoutPanel1.TabIndex = 7;
            // 
            // Caso1Button
            // 
            this.Caso1Button.Image = global::GestAca.GUI.Properties.Resources.Captura_de_pantalla_2023_03_12_194542;
            this.Caso1Button.Location = new System.Drawing.Point(3, 3);
            this.Caso1Button.Name = "Caso1Button";
            this.Caso1Button.Size = new System.Drawing.Size(431, 512);
            this.Caso1Button.TabIndex = 1;
            this.Caso1Button.Text = "Caso 1";
            this.Caso1Button.UseVisualStyleBackColor = true;
            this.Caso1Button.Click += new System.EventHandler(this.Caso_1_Button_Click);
            // 
            // Caso3Button
            // 
            this.Caso3Button.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Caso3Button.Image = global::GestAca.GUI.Properties.Resources.Captura_de_pantalla_2023_03_12_194556;
            this.Caso3Button.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.Caso3Button.Location = new System.Drawing.Point(440, 3);
            this.Caso3Button.Name = "Caso3Button";
            this.Caso3Button.Size = new System.Drawing.Size(462, 512);
            this.Caso3Button.TabIndex = 0;
            this.Caso3Button.Text = "Caso 3";
            this.Caso3Button.UseVisualStyleBackColor = true;
            this.Caso3Button.Click += new System.EventHandler(this.Caso_3_Button_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 521);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Caso7Button
            // 
            this.Caso7Button.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Caso7Button.Image = global::GestAca.GUI.Properties.Resources.Captura_de_pantalla_2023_03_16_001132;
            this.Caso7Button.Location = new System.Drawing.Point(920, 41);
            this.Caso7Button.Name = "Caso7Button";
            this.Caso7Button.Size = new System.Drawing.Size(446, 512);
            this.Caso7Button.TabIndex = 8;
            this.Caso7Button.Text = "Caso 7";
            this.Caso7Button.UseVisualStyleBackColor = true;
            this.Caso7Button.Click += new System.EventHandler(this.Caso_7_Button_Click);
            // 
            // GestAcaApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1445, 574);
            this.Controls.Add(this.Caso7Button);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.dateTimePicker1);
            this.Name = "GestAcaApp";
            this.Text = "GestAcaApp";
            this.Load += new System.EventHandler(this.MenuPrincipal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button Caso3Button;
        private System.Windows.Forms.Button Caso1Button;
        private System.Windows.Forms.Button Caso7Button;
        private System.Windows.Forms.Button button1;
    }
}

