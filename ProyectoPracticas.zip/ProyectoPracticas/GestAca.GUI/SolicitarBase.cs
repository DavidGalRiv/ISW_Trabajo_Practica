﻿using GestAca.Entities;
using GestAca.Persistence;
using GestAca.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestAca.GUI
{
    public partial class SolicitarBase : Form
    {
        protected IGestAcaService service;
        private DatosAlumno datosAlumno;
        private Student alumnoEncontrado;
        private TaughtCourse selected;
        private RegistrarAlumno registrarAlumno;
        private GestAcaCase7 gestAcaCase7;

        public SolicitarBase()
        {
            InitializeComponent();
        }

        public SolicitarBase(IGestAcaService service): this()
        {
            //InitializeComponent();
            this.service = service;
            this.IntroduceDNI.Clear();
            datosAlumno = new DatosAlumno(service);
            registrarAlumno = new RegistrarAlumno(service);
            gestAcaCase7 = new GestAcaCase7(service, alumnoEncontrado, selected);
        }

        protected void Cancel_Button_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.IntroduceDNI.Clear();
            Close();
        }

        public void SetCourse(TaughtCourse selected) // Método para recibir el curso
        {
            this.selected = selected;
        }

        //protected void Confirm_Button_Click(object sender, EventArgs e)
        //{
        //    //string dni = IntroduceDNI.Text.Trim().ToUpper();

        //    //if (dni.Length != 9 || !ValidarDni(dni))
        //    //{
        //    //    MessageBox.Show("DNI no válido. Introduzca un DNI correcto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    //    return;
        //    //}

        //    //alumnoEncontrado = service.FindAllStudents().FirstOrDefault(st => st.Id == dni);

        //    //if (alumnoEncontrado != null)
        //    //{
        //    //    DatosAlumno datosAlumno = new DatosAlumno(service);
        //    //    datosAlumno.SetStudent(alumnoEncontrado);
        //    //    datosAlumno.SetCourse(selected);
        //    //    this.Hide();
        //    //    datosAlumno.ShowDialog();
        //    //    this.Close();
        //    //}
        //    //else
        //    //{
        //    //    DialogResult answer = MessageBox.Show(
        //    //        "No se ha encontrado el alumno con ese DNI.\n¿Desea crear uno nuevo?",
        //    //        "Alumno no encontrado",
        //    //        MessageBoxButtons.YesNo,
        //    //        MessageBoxIcon.Question);

        //    //    if (answer == DialogResult.Yes)
        //    //    {
        //    //        RegistrarAlumno registrarAlumno = new RegistrarAlumno(service);
        //    //        registrarAlumno.SetDNI(dni);
        //    //        registrarAlumno.SetCourse(selected);

        //    //        // No ocultar `SolicitarDNI`
        //    //        this.Hide();
        //    //        registrarAlumno.ShowDialog();

        //    //        // Verificar si se registró el alumno al cerrar `RegistrarAlumno`
        //    //        alumnoEncontrado = service.FindAllStudents().FirstOrDefault(st => st.Id == dni);

        //    //        if (alumnoEncontrado != null)
        //    //        {
        //    //            DatosAlumno datosAlumno = new DatosAlumno(service);
        //    //            datosAlumno.SetStudent(alumnoEncontrado);
        //    //            datosAlumno.SetCourse(selected);
        //    //            //this.Close();
        //    //            //datosAlumno.ShowDialog();
        //    //            this.Show();
        //    //        }
        //    //    }
        //    //}
        //}


        //protected void IntroduceDNI_TextChanged(object sender, EventArgs e)
        //{
        //    //Coger el dni escrito por el usuario
        //    //string dni = IntroduceDNI.Text.Trim().ToUpper(); // Leer texto y convertir a mayúsculas
        //    //if (IntroduceDNI.TextLength == 9)
        //    //{
        //    //    MensajeDNI.Visible = true;
        //    //    if (this.ValidarDni(dni))
        //    //    {
        //    //        ConfirmButton.Enabled = true;
        //    //        //Intento de poner el texto de aviso conforme a un dni válido o incorrecto
        //    //        MensajeDNI.Text = "DNI válido.";
        //    //        MensajeDNI.ForeColor = Color.Green;
        //    //    }
        //    //    else
        //    //    {
        //    //        // Si el DNI no es válido, limpiar el TextBox
        //    //        ConfirmButton.Enabled = false;
        //    //        //Intento de poner el texto de aviso conforme a un dni válido o incorrecto
        //    //        MensajeDNI.Text = "DNI no válido.";
        //    //        MensajeDNI.ForeColor = Color.Red;
        //    //    }
        //    //}
        //    //else
        //    //{
        //    //    MensajeDNI.Visible = false;
        //    //    ConfirmButton.Enabled = false;
        //    //}
        //    //Si el dni está escrito correctamente dejará darle al botón de confirmar
        //}

        public Boolean ValidarDni(string dni)
        {
            int y;
            string z = dni.Substring(8, 1);
            if (!int.TryParse(dni.Substring(0, 8), out y))
            {
                //nosotros gestionamos los exceptions
                return false;
            }
            else
            {
                return true;
            }
        }

        public void ComprobarEstudiante(string dni) 
        {
            ICollection<Student> students = service.FindAllStudents();
            foreach (Student st in students) 
            {
                if (st.Id == dni) 
                { 
                    alumnoEncontrado = st;
                }
            }
        }
    }
}
